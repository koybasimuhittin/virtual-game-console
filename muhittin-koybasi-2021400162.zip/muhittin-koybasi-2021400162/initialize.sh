#!/bin/bash

IMAGE_NAME="storage_vgc.img"
IMAGE_SIZE="100M"
MOUNT_POINT="./mount"
LOOP_DEVICE="/dev/loop0"
DEVICE_LINK="./device-file"
BIN_DIR="./bin"

# Check for root privileges
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root. Use sudo."
   exit 1
fi

# Overwrite existing image if it exists
if [ -f "$IMAGE_NAME" ]; then
    echo "Existing image found. Overwriting..."
    rm -f "$IMAGE_NAME"
fi

# Create and format the disk image
dd if=/dev/zero of="$IMAGE_NAME" bs=1M count=100 status=progress
mkfs.ext4 "$IMAGE_NAME" > /dev/null

# Create mount point if it doesn't exist
if [ ! -d "$MOUNT_POINT" ]; then
    mkdir "$MOUNT_POINT"
fi

# Attach the image to a loop device
LOOP_DEVICE=$(losetup -f)
losetup "$LOOP_DEVICE" "$IMAGE_NAME"

# Mount the loop device
mount "$LOOP_DEVICE" "$MOUNT_POINT"

# Check if the bin directory exists
if [ ! -d "$BIN_DIR" ]; then
    echo "Error: bin directory does not exist. Ensure $BIN_DIR is present."
    umount "$MOUNT_POINT"
    losetup -d "$LOOP_DEVICE"
    exit 1
fi

# Copy the bin directory to the image
cp -r "$BIN_DIR" "$MOUNT_POINT"

# Unmount and detach the loop device
umount "$MOUNT_POINT"
losetup -d "$LOOP_DEVICE"

# Create a symbolic link to the loop device
ln -sf "$LOOP_DEVICE" "$DEVICE_LINK"

echo "Disk image $IMAGE_NAME created, formatted, and populated with bin directory successfully."
